#pragma once
#include <string>

namespace NetworkUtil {
	bool downloadFile(std::string name, std::string path, std::string url);
	std::string getStrings(const std::string& url);
}
