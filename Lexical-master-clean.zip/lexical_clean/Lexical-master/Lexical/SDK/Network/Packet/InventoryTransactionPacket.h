#pragma once
#include "Packet.h"
#include "../../World/Inventory/Transaction/ComplexInventoryTransaction.h"

class InventoryTransactionPacket : public Packet {
private:
	char pad_0x30[0x48];
public:
	InventoryTransactionPacket(std::unique_ptr<ComplexInventoryTransaction> transaction, bool isClientSide = false) {
		memset(this, 0x0, sizeof(InventoryTransactionPacket));
		using InvTransactionPacket_ctt = void(__thiscall*)(InventoryTransactionPacket*, std::unique_ptr<ComplexInventoryTransaction>, bool);
		static InvTransactionPacket_ctt constructor = reinterpret_cast<InvTransactionPacket_ctt>(Addresses::InventoryTransactionPacket_Constructor);
		constructor(this, std::move(transaction), isClientSide);
	}
};