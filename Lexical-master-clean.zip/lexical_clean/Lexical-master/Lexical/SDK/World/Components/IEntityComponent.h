#pragma once

struct IEntityComponent {};