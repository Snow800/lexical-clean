#pragma once

struct AnimationComponent {
};
